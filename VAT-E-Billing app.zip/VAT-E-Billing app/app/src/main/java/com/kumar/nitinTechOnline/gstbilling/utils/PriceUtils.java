package com.sree.sreeTechOnline.VATbilling.utils;

/**
 * Created by Ajay on 7/24/2017.
 */

public class PriceUtils {

    private float finalPrice;
    private int quantity;

    private float tax;
    private float rate;
    private float taxableValue;
    private float singleVAT;

    public PriceUtils(float finalPrice, int quantity, int taxSlab) {
        this.finalPrice = finalPrice;
        this.quantity = quantity;

        tax = ((float)taxSlab)/100;
    }

    public float getRate(){
        rate = finalPrice/(tax+1);
        rate = ((float)Math.round(rate*100))/100;
        return rate;
    }

    public float getTaxableValue(){
        taxableValue = rate * quantity;
        return taxableValue;
    }

    public float getSingleVAT(){
        singleVAT = taxableValue*(tax/2);
        singleVAT = ((float)Math.round(singleVAT*100))/100;
        return singleVAT;
    }

}
