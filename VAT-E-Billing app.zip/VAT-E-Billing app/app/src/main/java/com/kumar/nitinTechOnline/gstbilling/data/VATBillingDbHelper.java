package com.sree.sreeTechOnline.VATbilling.data;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;



public class VATBillingDbHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "VATBillsDB.db";
    private static final int VERSION = 1;

    public VATBillingDbHelper(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }


    @Override
    public void onCreate(SQLiteDatabase db) {

        final String CREATE_TABLE = "CREATE TABLE "  + VATBillingContract.VATBillingEntry.PRIMARY_TABLE_NAME + " (" +
                VATBillingContract.VATBillingEntry._ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                VATBillingContract.VATBillingEntry.PRIMARY_COLUMN_NAME + " TEXT NOT NULL, " +
                VATBillingContract.VATBillingEntry.PRIMARY_COLUMN_PHONE_NUMBER + " TEXT NOT NULL, " +
                VATBillingContract.VATBillingEntry.PRIMARY_COLUMN_DATE + " TEXT NOT NULL, " +
                VATBillingContract.VATBillingEntry.PRIMARY_COLUMN_STATUS + " TEXT NOT NULL);";

        db.execSQL(CREATE_TABLE);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public static void createBillTable(SQLiteDatabase db, String billId){

        final String CREATE_TABLE = "CREATE TABLE "  + VATBillingContract.VATBillingCustomerEntry.SECONDARY_TABLE_NAME + billId + " (" +
                VATBillingContract.VATBillingCustomerEntry._ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                VATBillingContract.VATBillingCustomerEntry.SECONDARY_COLUMN_ITEM_DESCRIPTION + " TEXT NOT NULL, " +
                VATBillingContract.VATBillingCustomerEntry.SECONDARY_COLUMN_FINAL_PRICE + " REAL NOT NULL, " +
                VATBillingContract.VATBillingCustomerEntry.SECONDARY_COLUMN_QUANTITY + " INTEGER NOT NULL, " +
                VATBillingContract.VATBillingCustomerEntry.SECONDARY_COLUMN_TAX_SLAB + " INTEGER NOT NULL);";

        db.execSQL(CREATE_TABLE);

    }

    public static void dropBillTable(SQLiteDatabase db, String billId){

        final String DROP_TABLE = "DROP TABLE IF EXISTS " + VATBillingContract.VATBillingCustomerEntry.SECONDARY_TABLE_NAME + billId;
        db.execSQL(DROP_TABLE);

    }

}
